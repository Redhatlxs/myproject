#添加如下代码
#coding=utf-8
import pymysql
pymysql.install_as_MySQLdb()

