# coding:utf-8
import xadmin
from xadmin.views import LoginView, CommAdminView

from app.models import *

# 定制网站信息
class LoginViewAdmin(LoginView):
    title = '学生信息管理系统'
xadmin.site.register(LoginView,LoginViewAdmin)

class GlobalSetting(CommAdminView):
    # 左上角及浏览器标题
    site_title = '学生信息管理系统'
    # 页脚版权信息
    site_footer = 'Copyright ©2019 Stumanage'
    # 左侧边栏
    menu_style = 'accordion'
xadmin.site.register(CommAdminView,GlobalSetting)

class StudentsAdmin(object):
    search_fields = ('name', 'class_name__class_name', 'subjects__name',)#筛选
    list_filter = ('sex',)#过滤
    list_display = ('name', 'sex', 'age', 'enter_date',)
    style_fields = {'subjects': 'checkbox-inline', }

    # 顺序排序
    ordering = ('age', 'name',)#排序
    # 逆序排序，在前面加一个减号"-"，例如按年龄倒序排列
    ordering = ('-age',)

# 注册
xadmin.site.register(Students, StudentsAdmin)

class ClassAdmin(object):
    list_display = ('class_name',)
xadmin.site.register(Class, ClassAdmin)

class SubjectsAdmin(object):
    list_display = ('name',)
xadmin.site.register(Subjects, SubjectsAdmin)


class TeachersAdmin(object):
    list_display = ('name',)
xadmin.site.register(Teachers,TeachersAdmin)

