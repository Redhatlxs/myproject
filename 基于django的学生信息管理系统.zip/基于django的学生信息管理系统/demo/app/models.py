import os

from django.db import models


# Create your models here.

# 创建教师信息表
class Teachers(models.Model):
    name = models.CharField(verbose_name='教师名称',max_length=50)

    class Meta:
        verbose_name='教师信息'
        verbose_name_plural =verbose_name
    def __str__(self):
        return self.name


# 创建班级类
class Class(models.Model):
    class_name = models.CharField(verbose_name='班级', max_length=77)
    # 教师和班级一对一关系
    teacher = models.OneToOneField(Teachers,verbose_name='班主任',on_delete=models.CASCADE,blank=True,null=True)

    class Meta:
        verbose_name = '班级'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.class_name

# 创建课程类
class Subjects(models.Model):
    name = models.CharField(verbose_name='课程名称', max_length=77)
    class Meta:
        verbose_name = '课程信息'
        verbose_name_plural = '课程信息'

    def __str__(self):
        return self.name


# 创建学生信息类
class Students(models.Model):
    SEX = (
        ('male', '男'),
        ('female', '女')
    )
    name = models.CharField(verbose_name='学生姓名', max_length=77)

    def get_photo(self, filename):
        print(filename)
        #print(os.path.splitext(filename))分离文件名与扩展名
        return os.path.join('photo',
                            '%s_%s,%s' % (self.class_name, self.name,os.path.splitext(filename)[1]))

    photo = models.ImageField(verbose_name='照片', upload_to=get_photo, blank=True, null=True)
    sex = models.CharField(choices=SEX, verbose_name='性别', max_length=77)
    age = models.IntegerField(verbose_name='年龄')
    address = models.CharField(verbose_name='家庭住址', max_length=100, blank=True)
    enter_date = models.DateField(verbose_name='入学时间')
    # 增加对Class(一)的引用 多对一（级联删除）
    class_name = models.ForeignKey(Class, verbose_name='所在班级', on_delete=models.CASCADE, blank=True, null=True)
    # 增加 学生和选修课的多对多关系
    subjects = models.ManyToManyField(Subjects,verbose_name='选修课',blank=True)
    remarks = models.TextField(verbose_name='备注', blank=True)
    # 标签优化
    class Meta:
        verbose_name = '学生信息'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name

